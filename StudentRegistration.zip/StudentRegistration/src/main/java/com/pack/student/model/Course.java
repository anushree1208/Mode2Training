package com.pack.student.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Course {

	@EmbeddedId
	private CourseDetails courseDetails;

	public CourseDetails getCourseDetails() {
		return courseDetails;
	}

	public void setCourseDetails(CourseDetails courseDetails) {
		this.courseDetails = courseDetails;
	}
	
	
}
