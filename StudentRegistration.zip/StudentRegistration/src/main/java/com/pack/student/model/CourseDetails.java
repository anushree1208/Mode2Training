package com.pack.student.model;

import javax.persistence.Embeddable;

@Embeddable
public class CourseDetails {

	private String collegeCode;
	private String collegeCourse;
	public String getCollegeCode() {
		return collegeCode;
	}
	public void setCollegeCode(String collegeCode) {
		this.collegeCode = collegeCode;
	}
	public String getCollegeCourse() {
		return collegeCourse;
	}
	public void setCollegeCourse(String collegeCourse) {
		this.collegeCourse = collegeCourse;
	}
	
	
}
