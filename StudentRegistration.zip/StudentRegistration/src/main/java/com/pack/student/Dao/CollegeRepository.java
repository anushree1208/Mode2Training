package com.pack.student.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pack.student.model.College;

public interface CollegeRepository extends JpaRepository<College,String>{

}
