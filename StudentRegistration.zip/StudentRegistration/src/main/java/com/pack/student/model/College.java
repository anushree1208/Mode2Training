package com.pack.student.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class College {

	
	private String collegeName;
	@Id
	private String collegeCode;
	private String collegePlace;
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String getCollegeCode() {
		return collegeCode;
	}
	public void setCollegeCode(String collegeCode) {
		this.collegeCode = collegeCode;
	}
	public String getCollegePlace() {
		return collegePlace;
	}
	public void setCollegePlace(String collegePlace) {
		this.collegePlace = collegePlace;
	}
	@Override
	public String toString() {
		return "College [collegeName=" + collegeName + ", collegeCode=" + collegeCode + ", collegePlace=" + collegePlace
				+ "]";
	}
	
	
	
}
