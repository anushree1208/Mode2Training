package com.pack.student.service;



import java.util.List;

import com.pack.student.model.AcademicDetails;
import com.pack.student.model.College;
import com.pack.student.model.Student;

public interface StudentService {

	public void addStudent(Student student1, AcademicDetails academic);
	
	public String findPlaceByUsn(String studentUsn);

	public List<Student> getStudentDetails(int pageNo,int total);

}

