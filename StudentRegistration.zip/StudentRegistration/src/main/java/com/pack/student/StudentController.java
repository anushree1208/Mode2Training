package com.pack.student;

import java.io.IOException;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.student.Dto.StudentDto;
import com.pack.student.model.AcademicDetails;
import com.pack.student.model.Student;
import com.pack.student.service.StudentService;

@Controller
public class StudentController {

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

	@Autowired(required = true)
	@Qualifier(value = "studentService")
	StudentService studentService;

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}

	@RequestMapping(value = "/student/add", method = RequestMethod.GET)
	public String saveCustomerPage(Model model) {
		logger.info("Entering into registration.jsp page");
		model.addAttribute("student", new StudentDto());
		return "registration";
	}

	@RequestMapping(value = "/student/save.do", method = RequestMethod.POST)
	public String saveCustomerAction(@ModelAttribute("student") StudentDto studentDto, Model model) {
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studentDto, Student.class);
		AcademicDetails academic = mapper.map(studentDto, AcademicDetails.class);
		model.addAttribute("student", studentDto);
		this.studentService.addStudent(student, academic);
		logger.info("Registration of student is success");
		return "success";
	}

	@RequestMapping(value = "/student/place.do", method = RequestMethod.GET)
	public String findClgCPlace(Model model) {
		logger.info("Get student college Usn");
		model.addAttribute("studentUsn", new StudentDto());
		return "writeUsn";
	}

	@RequestMapping(value = "/student/getplace", method = RequestMethod.POST)
	public String getPlace(@ModelAttribute("studentUsn") StudentDto studentDto, Model model) {
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studentDto, Student.class);
		String usn = student.getStudentUsn();
		System.out.println("Usn :" + usn);
		model.addAttribute("studentUsn", usn);
		model.addAttribute("place", this.studentService.findPlaceByUsn(usn));
		return "getPlace";

	}

	@RequestMapping(value = "/getStudent/{pageNo}")
	public String getStudentDetails(@PathVariable int pageNo, Model model) throws IOException {

		int total = 3;
		if (pageNo == 1) {
		} else {
			pageNo = (pageNo - 1) * total + 1;
		}
		System.out.println(pageNo);
		List<Student> listStudent = studentService.getStudentDetails(pageNo, total);
		// model.addObject("listStudent", listStudent);
		// model.setViewName("allStudentDetails");
		model.addAttribute("listStudent", listStudent);
		return "allStudentDetails";
	}
}
