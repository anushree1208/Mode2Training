package com.pack.student.Dao;

import java.util.List;

import com.pack.student.model.AcademicDetails;
import com.pack.student.model.College;
import com.pack.student.model.Student;

public interface StudentDao{
	
	public void addStudent(Student student1, AcademicDetails academic);

	public String findPlaceByUsn(String studentUsn);
	
	public List<Student> getStudentDetails(int pageNo,int total);
			
}