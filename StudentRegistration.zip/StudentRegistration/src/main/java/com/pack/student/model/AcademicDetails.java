package com.pack.student.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AcademicDetails {
	@Id
	private String studentUsn;
	private String course;
	private int semester;
	public String getStudentUsn() {
		return studentUsn;
	}
	public void setStudentUsn(String studentUsn) {
		this.studentUsn = studentUsn;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	
	
}
