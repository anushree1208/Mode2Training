package com.pack.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.student.Dao.StudentDao;
import com.pack.student.model.AcademicDetails;
import com.pack.student.model.College;
import com.pack.student.model.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao studentDao;

	public void setStudentDao(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

	// Adding Student Academic Details
	@Override
	@Transactional
	public void addStudent(Student student1, AcademicDetails academic) {
		// TODO Auto-generated method stub
		studentDao.addStudent(student1, academic);

	}

	// Finding Place Based on USN
	@Override
	@Transactional
	public String findPlaceByUsn(String studentUsn) {
		// TODO Auto-generated method stub
		return studentDao.findPlaceByUsn(studentUsn);

	}

	// Fetching Student Details
	@Override
	@Transactional
	public List<Student> getStudentDetails(int pageNo, int total) {
		// TODO Auto-generated method stub
		return studentDao.getStudentDetails(pageNo, total);
	}

}
