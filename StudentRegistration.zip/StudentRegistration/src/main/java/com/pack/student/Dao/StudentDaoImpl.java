package com.pack.student.Dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import com.pack.student.model.AcademicDetails;
import com.pack.student.model.College;
import com.pack.student.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao {

	private static final Logger logger = LoggerFactory.getLogger(StudentDaoImpl.class);
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public void addStudent(Student student1, AcademicDetails academic) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(student1);
		session.persist(academic);
		logger.info("student saved successfully, student Details=" + student1);
		logger.info("academicDetails saved successfully, academic Details=" + academic);
	}

	@Override
	public String findPlaceByUsn(String studentUsn) {
		// TODO Auto-generated method stub
		StringBuffer studentUsn1 = new StringBuffer(studentUsn);
		String place = null;
		String clgCode = studentUsn1.substring(0, 2);
		System.out.println(clgCode);
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("from College where collegeCode= :collegeCode");
		System.out.println("haii");
		query.setParameter("collegeCode", clgCode);
		List<College> list = query.list();
		Iterator<College> iterator = list.iterator();
		while (iterator.hasNext()) {
			Object obj = iterator.next();
			College clg = (College) obj;
			place = clg.getCollegePlace();
			System.out.println("hello");
		}
		return place;
	}
	
	
	@Override
	public List<Student> getStudentDetails(int pageNo,int total) {
	// TODO Auto-generated method stub
	Session session = this.sessionFactory.getCurrentSession();
	try {
	Query query = session.createQuery("from Student");
	query.setFirstResult(pageNo-1);
	query.setMaxResults(total);

	List<Student> students = query.list();
	return students;
	} catch (HibernateException e) {
	e.printStackTrace();
	session.getTransaction().rollback();
	}
	return null;
	}

}
