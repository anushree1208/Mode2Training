package com.pack.BookMyShow.Dto;

import java.time.LocalDate;

public class MovieDto {

	private String theaterName;
	private String place;
	private String showDate;
	private String theaterId;
	private String morningShow;
	private String noonShow;
	private String eveningShow;

	public String getTheaterName() {
		return theaterName;
	}

	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getShowDate() {
		return showDate;
	}

	public void setShowDate(String showDate) {
		this.showDate = showDate;
	}

	public String getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(String theaterId) {
		this.theaterId = theaterId;
	}

	public String getMorningShow() {
		return morningShow;
	}

	public void setMorningShow(String morningShow) {
		this.morningShow = morningShow;
	}

	public String getNoonShow() {
		return noonShow;
	}

	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}

	public String getEveningShow() {
		return eveningShow;
	}

	public void setEveningShow(String eveningShow) {
		this.eveningShow = eveningShow;
	}

}
