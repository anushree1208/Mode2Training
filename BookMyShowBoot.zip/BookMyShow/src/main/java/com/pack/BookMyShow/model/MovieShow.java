package com.pack.BookMyShow.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="MovieShow")
public class MovieShow{
	
	@Column(name="showDate")
	private String showDate;
	
	
	@Column(name="theaterId")
	private String theaterId;
	@Id
	private String showId;
	
	@Column(name="morningShow")
	private String morningShow;
	
	@Column(name="noonShow")
	private String noonShow;
	
	@Column(name="eveningShow")
	private String eveningShow;

	

	public String getShowDate() {
		return showDate;
	}

	public void setShowDate(String showDate) {
		this.showDate = showDate;
	}

	public String getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(String theaterId) {
		this.theaterId = theaterId;
	}

	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}

	public String getMorningShow() {
		return morningShow;
	}

	public void setMorningShow(String morningShow) {
		this.morningShow = morningShow;
	}

	public String getNoonShow() {
		return noonShow;
	}

	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}

	public String getEveningShow() {
		return eveningShow;
	}

	public void setEveningShow(String eveningShow) {
		this.eveningShow = eveningShow;
	}

	

}
