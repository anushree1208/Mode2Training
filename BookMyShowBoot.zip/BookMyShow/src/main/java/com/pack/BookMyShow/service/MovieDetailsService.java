package com.pack.BookMyShow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.BookMyShow.Dao.MovieDetailsDao;
import com.pack.BookMyShow.model.MovieDetails;

@Service
public class MovieDetailsService {

	
	@Autowired
	MovieDetailsDao movieDetailsDao ;
	
	public void addMovie(MovieDetails movieDetails) {
		movieDetailsDao.save(movieDetails);
		
	}
}
