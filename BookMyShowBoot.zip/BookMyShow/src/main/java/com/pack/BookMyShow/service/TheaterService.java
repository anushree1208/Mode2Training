package com.pack.BookMyShow.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.BookMyShow.Dao.TheaterDao;
import com.pack.BookMyShow.model.Theater;



@Service
public class TheaterService {

	@Autowired
	TheaterDao theaterDao;
	
	public void addtheater(Theater theater) {
		theaterDao.save(theater);
	}

public Iterable<Theater> getListTheater() {
	 return theaterDao.findAll();
	 
}

}


