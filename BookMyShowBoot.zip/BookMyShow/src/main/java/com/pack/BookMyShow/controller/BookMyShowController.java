package com.pack.BookMyShow.controller;


import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pack.BookMyShow.Dto.BookingDto;
import com.pack.BookMyShow.Dto.MovieDto;
import com.pack.BookMyShow.model.MovieDetails;
import com.pack.BookMyShow.model.MovieShow;
import com.pack.BookMyShow.model.Theater;
import com.pack.BookMyShow.model.User;
import com.pack.BookMyShow.service.MovieDetailsService;
import com.pack.BookMyShow.service.MovieShowService;
import com.pack.BookMyShow.service.TheaterService;
import com.pack.BookMyShow.service.UserService;

@RestController
public class BookMyShowController {

	private static final Logger logger = LoggerFactory.getLogger(BookMyShowController.class);

	@Autowired
	UserService userService;
	
	@Autowired
	TheaterService theaterService ;
	
	@Autowired
	MovieDetailsService movieDetailsService;
	
	@Autowired
	MovieShowService movieShowService;

	@PostMapping("/add/user")
	public String addUser(@RequestBody User user) {
		logger.info("adding user Details");
		userService.addUserDetails(user);
		System.out.println("hello");
		return "successfully added user";

	}

	@PostMapping("/add/theater")
	public String addTheater(@RequestBody Theater theater) {
		logger.info("adding theater Details");
		theaterService.addtheater(theater);
		return "Adding theater Successfully";

	}
	
	@PostMapping("/add/movie")
	public String addMovie(@RequestBody MovieDetails movieDetails){
		logger.info("movie is added");
		movieDetailsService.addMovie(movieDetails);
		return "movie details added successfully";
		
	}

	
	@PostMapping("/add/show")
	public String addShow(@RequestBody MovieShow movieShow ) {
		logger.info("Adding movie shows ");
		movieShowService.addShow(movieShow);
		return "added movie";
	}
	

	
	@GetMapping("/add/theater/list")
	public Iterable<Theater> getTheatreList() {
		logger.info("get theater list");
		return theaterService.getListTheater();
	}
	
	
	@GetMapping("/add/movie1")
	public List<MovieDto> getShowList(@RequestParam("movieName") String movieName,@RequestParam("showDate") String showDate ) {
		logger.info("get movie details");
		return movieShowService.getShowList(movieName, showDate);
		  
	}
	
	@GetMapping("/add/movieShow")
	public List<MovieShow> getMovieShowList(@RequestParam("movieName") String movieName,@RequestParam("showDate") String showDate ) {
		return movieShowService.getmovieList(movieName, showDate);
		  
	}
	
	@GetMapping("add/bookingDetails")
	 public BookingDto getBookingDetails(@RequestParam("movieName")String movieName,
	 @RequestParam("showDate") String showDate, @RequestParam("theaterId") String theaterId,
	 @RequestParam("userId") Integer userId) {
		logger.info("do Booking");
	 return movieShowService.doBooking(movieName, showDate, theaterId, userId);


	}

	
}
