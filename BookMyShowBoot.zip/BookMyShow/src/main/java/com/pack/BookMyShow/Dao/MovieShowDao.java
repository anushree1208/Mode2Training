package com.pack.BookMyShow.Dao;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pack.BookMyShow.model.MovieShow;

@Repository
public interface MovieShowDao extends CrudRepository<MovieShow, String> {

	@Query(value="select * from theater t where t.theater_id  in (select s.theater_id from movie_show s where (s.morning_show= ?1) or (s.noon_show= ?1) or (s.evening_show= ?1) and s.show_date= ?2)", nativeQuery = true)
	public List<String> getShowTime(@Param(value = "movieName") String movieName,
			@Param(value = "showDate") String showDate);
	
	@Query(value="select * from  movie_show s  where (evening_show = ?1 or noon_show=?1 or morning_show=?1 and show_date=?2 )" ,nativeQuery = true)
	public List<MovieShow> getMovieShow(@Param(value = "movieName") String movieName,
			@Param(value = "showDate") String showDate);
			



/*@Query(value="select s from movie_show  s where s.morning_show= :movieName or s.noon_show= :movieName or s.evening_show= :movieName", nativeQuery = true)
public List<MovieShow> getShow(@Param(value="movieName") String movieName , @Param(value="showDate") String showDate);

}*/
}                                                                    