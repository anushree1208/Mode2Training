package com.pack.BookMyShow.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "MovieDetails")
public class MovieDetails {

	@Id
	@Column(name = "movieName")
	private String movieName;

	@Column(name = "language")
	private String language;

	@Column(name = "releaseDate")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate releaseDate;

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public LocalDate getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	

}
