package com.pack.BookMyShow.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.BookMyShow.Dao.BookingDao;
import com.pack.BookMyShow.Dao.MovieShowDao;
import com.pack.BookMyShow.Dao.TheaterDao;
import com.pack.BookMyShow.Dto.BookingDto;
import com.pack.BookMyShow.Dto.MovieDto;
import com.pack.BookMyShow.model.Booking;
import com.pack.BookMyShow.model.MovieShow;
import com.pack.BookMyShow.model.Theater;

@Service
public class MovieShowService {

	@Autowired
	MovieShowDao movieShowDao;

	@Autowired
	TheaterDao theaterDao;
	
	@Autowired
	BookingDao bookingDao;

	public String addShow(MovieShow movieShow) {
		movieShowDao.save(movieShow);
		return "added";

	}

	public List<MovieShow> getmovieList(String movieName, String showDate) {
		List list = movieShowDao.getMovieShow(movieName, showDate);
		return list;

	}

	public List<MovieDto> getShowList(String movieName, String showDate) {
		Iterable<Theater> theater = theaterDao.findAll();
		// List theaterList = movieShowDao.getShowTime(movieName, showDate);
		List<MovieShow> movieShowList = movieShowDao.getMovieShow(movieName, showDate);
		List<MovieDto> movieDtoList = new ArrayList<MovieDto>();
		Iterator<MovieShow> iteratorMovie = movieShowList.iterator();
		Theater theaterObj = new Theater();
		while (iteratorMovie.hasNext()) {
			MovieDto movieDto = new MovieDto();
			MovieShow movieShow = iteratorMovie.next();
			theaterObj = theaterDao.findById(movieShow.getTheaterId()).orElse(null);
			movieDto.setTheaterName(theaterObj.getTheaterName());
			movieDto.setTheaterId(theaterObj.getTheaterId());
			movieDto.setPlace(theaterObj.getPlace());
			movieDto.setEveningShow(movieShow.getEveningShow());
			movieDto.setNoonShow(movieShow.getNoonShow());
			movieDto.setMorningShow(movieShow.getMorningShow());
			movieDto.setShowDate(movieShow.getShowDate());
			movieDtoList.add(movieDto);
		}

		return movieDtoList;

	}

	public BookingDto doBooking(String movieName, String showDate, String theaterId, Integer userId) {

		ModelMapper mapper = new ModelMapper();
		List<MovieDto> movieList = getShowList(movieName, showDate);
		Iterator<MovieDto> movie = movieList.iterator();
		// BookingDto bookingDto = new BookingDto();
		BookingDto bookingDto = new BookingDto();
		while (movie.hasNext()) {
			MovieDto movieShow = movie.next();
			bookingDto.setMovieName(movieName);
			bookingDto.setShowDate(movieShow.getShowDate());
			bookingDto.setTheaterName(movieShow.getTheaterName());
			bookingDto.setUserId(userId);
			bookingDto.setPlace(movieShow.getPlace());
			if (movieShow.getMorningShow().equals(movieName))
				bookingDto.setShowTime("MorningShow");
			if (movieShow.getEveningShow().equals(movieName))
				bookingDto.setShowTime("EveningShow");
			if (movieShow.getNoonShow().equals(movieName))
				bookingDto.setShowTime("NoonShow");
			
			Booking booking = mapper.map(bookingDto,Booking.class);
			
			bookingDao.save(booking);
		}
		return bookingDto;
	}

}
