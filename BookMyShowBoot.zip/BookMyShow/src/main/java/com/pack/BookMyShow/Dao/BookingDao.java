package com.pack.BookMyShow.Dao;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.pack.BookMyShow.model.Booking;


@Repository
public interface BookingDao extends CrudRepository<Booking, Integer>{

}
