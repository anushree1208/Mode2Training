package com.pack.BookMyShow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.BookMyShow.Dao.UserDao;
import com.pack.BookMyShow.model.User;

@Service
public class UserService {

	
	@Autowired
	UserDao userDao;
	
	public String addUserDetails(User user) {
		/*
		 * user.setUserId(user.getUserId()); user.setUserName(user.getUserName());
		 * user.setEmail(user.getEmail()); user.setPhoneNum(user.getPhoneNum());
		 */
		userDao.save(user);
		return "successfully adding user";
	}
}
