package com.bank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BankDemo {

	private static final String List = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Customer c = new Customer();
		System.out.println("Enter the number");
		int n = s.nextInt();

		String[] arr = new String[n];

		List<String> list4 = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			String arr1 = (String) s.nextLine();
			list4.add(arr1);

		}

		List<Customer> list = Arrays.asList(

				new Customer("Anushree", 15, "1235617812", "11111", 500000),
				new Customer("Swathi", 22, "9609890876", "66666", 100000),
				new Customer("Anu", 25, "9609890876", "22222", 200000),
				new Customer("krupa", 21, "9609890876", "77777", 150000),

				new Customer("krupa", 21, "9609890876", "369854", 100000),
				new Customer("sahana", 21, "9609890876", "33333", 500000),
				new Customer("abc", 22, "1236547897", "44444", 700000),
				new Customer("Rani", 22, "9845522562", "55555", 900000),
				new Customer("Shilpa", 24, "7411101041", "88888", 100000),
				new Customer("Priya", 23, "123645598", "999990", 500000));

		// List<Customer> list1 = c.custList(list,list4);

		List acc = list4.stream().map(x -> "SBI" + x).filter(x -> x.length() == 8).limit(10)
				.collect(Collectors.toList());

		System.out.println(acc);

		System.out.println("PhoneValidation");

		List<Customer> custList = list.stream().filter(x -> x.ph.length() == 10).collect(Collectors.toList());

		System.out.println("age Validation");

		custList = custList.stream().filter(x -> x.age > 18).collect(Collectors.toList());

		custList = custList.stream().filter(x -> Character.isUpperCase(x.accName.charAt(0)))
				.collect(Collectors.toList());

		accLink(custList, acc);

		dispCustList(custList);

		custList = custList.stream().sorted((s1, s2) -> s1.getAccName().compareTo(s2.getAccName()))

				.collect(Collectors.toList());

		dispCustList(custList);

		System.out.println("Enter your account number");

		String nll = s.nextLine();

		String accNo = s.nextLine();

		/*
		 * for (int i = 0; i < custList1.size(); i++) {
		 * 
		 * 
		 * // System.out.println("Hello");
		 * 
		 * 
		 * if (accNo.equals(custList1.get(i).accNum)) {
		 * 
		 * 
		 * BankOperations b = new BankOperations();
		 * 
		 * 
		 * System.out.println("Enter the amount");
		 * 
		 * 
		 * double amount = s.nextDouble();
		 * 
		 * 
		 * b.withdraw(custList1.get(i), amount);
		 * 
		 * 
		 * }
		 * 
		 * 
		 * }
		 */

		String m = null;

		do {

			System.out.println("Enter your option");

			System.out.println("1.Withdraw\t2.Deposit\t3.Withdraw List Display\t4.Exit");

			m = s.nextLine();

			for (int i = 0; i < custList.size(); i++) {

				if (accNo.equals(custList.get(i).accNum)) {

					switch (m) {

					case "1":

						BankOperations b = new BankOperations();

						System.out.println("Enter the amount");

						double amount = s.nextDouble();

						b.withdraw(custList.get(i), amount);

						break;

					case "2":

						BankOperations b1 = new BankOperations();

						System.out.println("Enter the amount");

						amount = s.nextDouble();

						b1.deposit(custList.get(i), amount);

						break;

					case "3":

						BankOperations b2 = new BankOperations();

						b2.display(custList.get(i));

						break;

					case "4":

						break;

					}

				}

			}

		} while (!m.equals("4"));

	}

	private static void dispCustList(List<Customer> custList) {
		System.out.println("-----------------------------------------------------");
		System.out.println("AccName" + "\t" + "Age" + "\t" + "phoneNum" + "\t" + "AccNumber" + "\t" + "Balance");
		System.out.println("-----------------------------------------------------");
		// TODO Auto-generated method stub
		for (int i = 0; i < custList.size(); i++) {
			System.out.println(
					custList.get(i).getAccName() + "\t" + custList.get(i).getAge() + "\t" + custList.get(i).getPh()
							+ "\t" + custList.get(i).getAccNum() + "\t" + custList.get(i).getBalance());
		}
	}

	private static void accLink(List<Customer> custList, List<String> acc) {
		// TODO Auto-generated method stub
		for (int i = 0; i < custList.size(); i++) {
			custList.get(i).accNum = acc.get(i);
		}
	}

}
