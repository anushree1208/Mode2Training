package com.bank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list = Arrays.asList("12345", "89078", "56788", "3245567", "32467", "63256", "73278", "8912369",
				"987213", "53125");
		Customer[] cust = new Customer[10];
		
		Scanner in = new Scanner(System.in);
		String accNum;
		for (int i = 0; i < 10; i++) {
			System.out.println("Enter the AccountHolder name :");
			String accName = in.nextLine();
			System.out.println("Enter the AccountHolder age :");
			int age = in.nextInt();
			System.out.println("Enter the AccountHolder PhoneNum");
			String ph = in.nextLine();
			System.out.println("Enter the Withdrawal Amt");
			double withAmt=in.nextDouble();
			accNum = list.get(i);
			System.out.println("Account Number of AccountHolder :" +accNum);
			List<Customer> custList = Arrays.asList(new Customer(accName,age,ph,accNum,withAmt));
			
		}
		
		for(int i=0;i<10;i++){
			System.out.println("-----------------------------------------------------");
			System.out.println("AccName"+ "\t" + "Age" + "\t" + "phoneNum" +"\t" +"AccNumber");
			System.out.println("-----------------------------------------------------");
			System.out.println(cust[i].getAccName()+"\t" + cust[i].getAge() + "\t" + cust[i].getPh()+"\t"+cust[i].getAccNum());
		}
	}

}
