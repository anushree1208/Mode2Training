package com.bank;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	String accName;
	int age;
	String ph;
	String accNum;
	double balance = 100000;
	double withAmt;
List <Double>withdrawList = new ArrayList<Dsouble>();
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String accName, int age, String ph, String accNum, double balance) {
		super();
		this.accName = accName;
		this.age = age;
		this.ph = ph;
		this.accNum = accNum;
		this.balance = balance;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPh() {
		return ph;
	}

	public void setPh(String ph) {
		this.ph = ph;
	}

	public String getAccNum() {
		return accNum;
	}

	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getWithAmt() {
		return withAmt;
	}

	public void setWithAmt(double withAmt) {
		this.withAmt = withAmt;
	}

	@Override
	public String toString() {
		return "Customer [accName=" + accName + ", age=" + age + ", ph=" + ph + ", accNum=" + accNum + ", balance="
				+ balance + ", withAmt=" + withAmt + "]";
	}

public	List custList(List list,List list4){
	
	
	return list;
	
}

	public void withdrawAmt(double withAmt) {
		balance = balance - withAmt;
		System.out.println("Balance amount Atter Withdrawing" + withAmt + "is" + balance);
	}

}
