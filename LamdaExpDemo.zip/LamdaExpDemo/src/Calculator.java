import java.util.function.BiFunction;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Cal cal = new Cal();
	    String result = cal.calc((a, b) -> ": " + (a * b),3,  5);

	    System.out.println(result);

	    
	    BiFunction<Integer, Integer, Integer>adder = Cal::add;  
	    int result1 = adder.apply(10, 20);  
	    System.out.println(result1);  

		
	}
}

class Cal{
	public String calc(BiFunction<Integer, Integer, String> bi, Integer i1, Integer i2) {
	      return bi.apply(i1, i2);
	  }

	
	public static int add(int a, int b){  
		return a+b;  

}
}