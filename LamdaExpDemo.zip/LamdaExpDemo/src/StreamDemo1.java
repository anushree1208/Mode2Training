import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> intList = Arrays.asList(1, 2, 35, 67, 8, 4, 7, 2, 7, 7, 8, 43, 9);
		List distinctList = intList.stream().distinct().collect(Collectors.toList());
		System.out.println(distinctList);

		/*
		 * List[] list = intList.stream().toArray(List[]::new);
		 * 
		 * System.out.println(Arrays.toString(list));
		 */

		Stream<Integer> it = Arrays.asList(2, 4, 56, 8, 5, 67, 7, 4).stream();
		Integer[] arr = it.toArray(Integer[]::new);
		System.out.println(Arrays.toString(arr));
		Stream<String> tokenStream = Arrays.asList("A", "B", "C", "D").stream(); // stream
		String[] tokenArray = tokenStream.toArray(String[]::new); // array
		System.out.println(Arrays.toString(tokenArray));

		List<Integer> list1 = Arrays.asList(1, 2, 3);
		List<Integer> list2 = Arrays.asList(4, 5, 6);
		List<Integer> list3 = Arrays.asList(7, 8, 9);
		List<List<Integer>> listOfLists = Arrays.asList(list1, list2, list3);
		List<Integer> listOfAllIntegers = listOfLists.stream().flatMap(x -> x.stream()).collect(Collectors.toList());
		System.out.println(listOfAllIntegers);

		List list11 = intList.stream().filter(e->e>20).peek(System.out::println).collect(Collectors.toList());
		
		long total = intList.stream().count();
		System.out.println("total nums :" +total);
		
		Integer maxNum = intList.stream().max(Comparator.comparing(Integer::valueOf)).get();
		
		Integer minNum = intList.stream().min(Comparator.comparing(Integer::valueOf)).get();
		
		System.out.println("Maximum Number :"+maxNum);
		System.out.println("Minimum Number :"+minNum);
		
		
		Integer list21 = intList.stream().filter(x->x%2==0).reduce(0,(ans,i)->ans+i);
		
		System.out.println(list21);
		
		
	}

}
