package com.example.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BenificiaryDao;
import com.example.demo.model.Beneficiary;


@Service
public class BeneficiaryService {
	@Autowired
	BenificiaryDao beneficiarydao;

	public String add_custdetails(Beneficiary beneficiary) {
		beneficiary.setCust_id(beneficiary.getCust_id());
		beneficiary.setBaccno(beneficiary.getBaccno());
		beneficiary.setIfsc(beneficiary.getIfsc());
		beneficiarydao.save(beneficiary);
		return "successfully";
	}

	public Beneficiary findByIfsccode(String ifsc) {
		return beneficiarydao.findByifsc(ifsc);
	}
	public Beneficiary findByifscAndBaccno(String ifsc,String baccno)
	{
		return beneficiarydao.findByifscAndBaccno(ifsc, baccno);
	}
	 
}